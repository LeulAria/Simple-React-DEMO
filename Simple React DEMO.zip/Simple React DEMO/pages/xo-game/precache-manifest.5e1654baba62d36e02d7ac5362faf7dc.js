self.__precacheManifest = [
  {
    "revision": "33f107081e087b1175b811903d9ffab6",
    "url": "/static/media/play.33f10708.png"
  },
  {
    "revision": "04d2c8c31d30e2d7f2d43573ca19cf09",
    "url": "/static/media/pause.04d2c8c3.png"
  },
  {
    "revision": "fdfcfda2d9b1bf31db52",
    "url": "/static/js/runtime~main.fdfcfda2.js"
  },
  {
    "revision": "4103b98b6299e784c64b",
    "url": "/static/js/main.4103b98b.chunk.js"
  },
  {
    "revision": "61fbc54d5278bc8a28aa",
    "url": "/static/js/2.61fbc54d.chunk.js"
  },
  {
    "revision": "4103b98b6299e784c64b",
    "url": "/static/css/main.649b2559.chunk.css"
  },
  {
    "revision": "9cb3df1d2f2832969ffad47e9e49361f",
    "url": "/index.html"
  }
];